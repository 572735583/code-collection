#ifndef __FUNCTION_H
#define	__FUNCTION_H


void Communication_Decode(void);
void Cruising(void);


#endif /* __FUNCTION_H */